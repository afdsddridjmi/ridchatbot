"""Tests isolés sans clé et sans réseau : python -m unittest discover -s tests -v"""
import io
import unittest
import wave
from unittest.mock import patch, Mock

from albert_api import check_wav, transcribe, chat, AlbertError


def wav_seconds(seconds: float = 1.0) -> bytes:
    b = io.BytesIO()
    with wave.open(b, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(16000)
        wav.writeframes(b'\x00\x00' * int(seconds * 16000))
    return b.getvalue()


class AlbertApiTests(unittest.TestCase):
    def test_acceptable_audio(self):
        self.assertAlmostEqual(check_wav(wav_seconds(3)), 3.0)

    def test_audio_too_long(self):
        with self.assertRaises(AlbertError):
            check_wav(wav_seconds(95))

    def test_audio_invalid(self):
        with self.assertRaises(AlbertError):
            check_wav(b'bad')

    @patch('albert_api.requests.post')
    def test_transcription_request(self, post):
        post.return_value = Mock(status_code=200)
        post.return_value.json.return_value = {'text': 'Bonjour, la réunion était utile.'}
        self.assertIn('réunion', transcribe('dummy', wav_seconds(1)))
        kwargs = post.call_args.kwargs
        self.assertEqual(kwargs['data']['language'], 'fr')
        self.assertEqual(kwargs['files']['file'][2], 'audio/wav')

    @patch('albert_api.requests.post')
    def test_conversation_request(self, post):
        post.return_value = Mock(status_code=200)
        post.return_value.json.return_value = {'choices': [{'message': {'content': 'Pourquoi ?'}}]}
        self.assertEqual(chat('dummy', [{'role': 'user', 'content': 'Salut'}]), 'Pourquoi ?')
        self.assertIn('Bearer dummy', post.call_args.kwargs['headers']['Authorization'])

    @patch('albert_api.requests.post')
    def test_no_error_response_leak(self, post):
        post.return_value = Mock(status_code=401)
        post.return_value.text = 'secret-not-to-show'
        with self.assertRaises(AlbertError) as ctx:
            chat('dummy', [{'role': 'user', 'content': 'Salut'}])
        self.assertNotIn('secret-not-to-show', str(ctx.exception))


if __name__ == '__main__':
    unittest.main()
